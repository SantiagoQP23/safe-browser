
#mongodb_cnn = "mongodb+srv://<username>:<password>@miclustercafe.1rxey.mongodb.net/test"
import pymongo

mongodb_cnn = "mongodb+srv://user_python:fbhXsvaHMMGLSNiX@miclustercafe.1rxey.mongodb.net/packetsdb"

client = pymongo.MongoClient(mongodb_cnn)

db = client.packetsdb

collection = db.packets

#collection.insert_one({"name": "John", "address": "Highway 37"})

#x = collection.find_one()

#print(x)

packets = collection.find();

for packet in packets:
    print(packet)



from pymongo import MongoClient


class UrlService: 
    def __init__(self):
        self.client = MongoClient(mongodb_cnn)
        try:
            db_list = self.client.list_database_names()
            print("Conexión exitosa!")
        except Exception as e:
            print("Error al conectar a la base de datos:", e)
        self.db = self.client["packetsdb"]
        self.collection = self.db["urls"]

    def insert(self, data):
        result = self.collection.insert_one(data)
        return result.inserted_id

    def find(self, query):
        return self.collection.find(query)

    def delete(self, query):
        result = self.collection.delete_one(query)
        return result.deleted_count


urlService = UrlService()